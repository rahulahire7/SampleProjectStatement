package com.lnt.event.Dao;

public interface IAdminLoginDao {

	public int checkAdmin(String adminName,String adminPassword);

}
