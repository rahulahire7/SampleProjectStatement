/**
 * 
 */
package com.lnt.event.Dao;

import java.util.List;

import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;

/**
 * @author Pracheta,Shyam
 * @Last-Modified Date:09-06-2018
 * @Last-Modified Time:15:55
 */
public interface ISpeakerManagementDao {
	
	
	public void addSpeaker(Speaker speaker);
	
	public Speaker getSpeakerById(int speakerId);
	/*public List<Users> listUsers();
	 * public List<Users> listUsers();*/
}
