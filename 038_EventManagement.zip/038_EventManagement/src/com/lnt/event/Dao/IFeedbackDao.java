/**
 * 
 */
package com.lnt.event.Dao;

import java.util.ArrayList;

import com.lnt.event.model.Feedback;

/**
 * @author prajakta,pracheta
 *
 */
public interface IFeedbackDao {

	public void addFeedback(Feedback feedback);

	public ArrayList<Feedback> getAllFeedback();

	public Feedback getFeedbackById(int feedbackId);

}
