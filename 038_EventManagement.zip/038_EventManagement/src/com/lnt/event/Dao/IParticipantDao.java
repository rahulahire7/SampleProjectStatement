package com.lnt.event.Dao;



public interface IParticipantDao {
	
	 public boolean checkLogin(String mail, String password);
}
