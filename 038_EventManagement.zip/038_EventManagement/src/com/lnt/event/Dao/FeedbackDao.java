package com.lnt.event.Dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.event.model.Feedback;

/**
 * @author prajakta,pracheta
 *
 */
@Repository
public class FeedbackDao implements IFeedbackDao {
	private SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(FeedbackDao.class);

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Override
	public ArrayList<Feedback> getAllFeedback() {
		Session session = this.sessionFactory.getCurrentSession();
		ArrayList<Feedback> feedbackList = (ArrayList<Feedback>) session.createQuery("from Feedback").list();
		for (Feedback feedback : feedbackList) {
			logger.info("Feedback List::" + feedback);
		}
		return feedbackList;
	}

	@Override
	public void addFeedback(Feedback feedback) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(feedback);
		logger.info("Feedback saved successfully, Feedback Details=" + feedback);

	}

	@Override
	public Feedback getFeedbackById(int feedbackId) {
		Session session = this.sessionFactory.getCurrentSession();
		Feedback feedback = (Feedback) session.load(Feedback.class, new Integer(feedbackId));
		logger.info("Feedback loaded successfully, Feedback details=" + feedback);
		return feedback;
	}

}
