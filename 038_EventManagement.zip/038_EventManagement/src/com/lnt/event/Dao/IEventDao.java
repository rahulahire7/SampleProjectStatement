package com.lnt.event.Dao;

import java.util.List;

import com.lnt.event.model.Event;
import com.lnt.event.model.Users;

public interface IEventDao {

	public void addEvents(Event event);// adding an event to list
	public void updateEvents(Event event);// update any event
	public List<Event> listEvents(); // entire list 
	public Event getEventByName(Integer eventId); //search 
	 public void removeEvent(Integer eventId);
	public List<Users> listUsers();
	 

}
