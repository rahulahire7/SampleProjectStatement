package com.lnt.event.Dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.lnt.event.model.Event;
import com.lnt.event.model.Users;


@Repository
public class EventDao implements IEventDao {
	
	private SessionFactory sessionFactory;
	private static final Logger logger = LoggerFactory.getLogger(EventDao.class);
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addEvents(Event event) {
	 Session session=this.sessionFactory.getCurrentSession();
	 session.persist(event);
	 logger.info("event is added to the Event_Table="+event);
	}

	@Override
	public void updateEvents(Event event) {
		Session session=this.sessionFactory.getCurrentSession();
		session.update(event);
	}	
	

	@SuppressWarnings("unchecked")
	@Override
	public List<Event> listEvents() {
		 Session session=this.sessionFactory.getCurrentSession();
		 List<Event> eventList=session.createQuery("from Event").list();
		 for (Event event : eventList) {
			 logger.info("Event List:" + event);
		}
		 
		return eventList;
	}

	@Override
	public Event getEventByName(Integer eventId) {
		Session session=this.sessionFactory.getCurrentSession();
		 Event event=(Event) session.load(Event.class, new Integer(eventId));
		logger.info("Events table loaded successfully, Event details=" + event);
		return event;
	}

	@Override
	public void removeEvent(Integer eventId) {
		Session session=this.sessionFactory.getCurrentSession();
		 Event event=(Event) session.load(Event.class, new Integer(eventId));
		 if(null!=event)
		 {
			 session.delete(event);
		 }
			logger.info("Events table loaded successfully, Event details=" + event);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Users> listUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		/*String sql = "select u.userId,u.firstName+u.lastName  AS"
				+ " USERNAME,u.address FROM Users u,Event e where u.userId=e.userId";*/
		Criteria creCriteria = session.createCriteria(Users.class); 
		Query query = session.createQuery("FROM Users u,Event e where u.userId=e.userId"); 
		// quer.list(); we don't need to use 
		List<Users> result = creCriteria.list(); 
		for (Users users : result) {
			logger.info("user list" + users);
		}
		return result;
	}

}





