/**
* 
*/
package com.lnt.event.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;

/**
 * @author Team Event Management
 *
 */
@Repository
public class SpeakerManagementDao implements ISpeakerManagementDao {
	private SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(SpeakerManagementDao.class);

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
public void addSpeaker(Speaker speaker) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(speaker);
		logger.info("Speaker saved successfully, Speaker Details=" + speaker);

	}

	@Override
	public Speaker getSpeakerById(int speakerId) {
		Session session = this.sessionFactory.getCurrentSession();
		return (Speaker) session.load(Speaker.class, speakerId);

	}

	/*@SuppressWarnings("unchecked")
	@Override
	public List<Users> listUsers() {
		Session session = this.sessionFactory.getCurrentSession();
		String sql = "select u.userId,u.firstName+u.lastName  AS"
				+ " USERNAME,u.address FROM Users u,Event e where u.userId=e.userId"; 
		List<Users> listUser = (List<Users>) session.createQuery(sql).list();
		for (Users users : listUser) {
			logger.info("user list" + users);
		}
		return listUser;
	}*/

}
