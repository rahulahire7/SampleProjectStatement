/**
* 
*/
package com.lnt.event.Dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.event.model.Users;

/**
 * @author Team Event Management
 *
 */
@Repository
public class EventMgmtDao implements IEventMgmtDao {
	private SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(EventMgmtDao.class);

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	@Override
	public void addUser(Users user) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(user);
		logger.info("Person saved successfully, Person Details=" + user);
		
	}

	@Override
	public Users getUserById(int userId) {
		Session session = this.sessionFactory.getCurrentSession();
		return (Users) session.load(Users.class, userId);
		
	}

}
