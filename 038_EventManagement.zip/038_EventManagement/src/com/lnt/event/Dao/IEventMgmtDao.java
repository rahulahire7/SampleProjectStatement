/**
 * 
 */
package com.lnt.event.Dao;

import com.lnt.event.model.Users;

/**
 * @author Pracheta,Shyam
 * @Last-Modified Date:09-06-2018
 * @Last-Modified Time:15:55
 */
public interface IEventMgmtDao {
	
	
	public void addUser(Users user);

	public Users getUserById(int userId);
}
