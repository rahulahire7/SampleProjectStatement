package com.lnt.event.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ParticipantDao implements IParticipantDao{
	
	private SessionFactory sessionFactory;
	private static final Logger logger = LoggerFactory.getLogger(ParticipantDao.class);

	@Autowired
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}


@Override
public boolean checkLogin(String mail, String password) {
	System.out.println("In Check login");
	Session session = sessionFactory.openSession();
    	
    	boolean userFound = false;
    	
    	
		//Query using Hibernate Query Language
		String SQL_QUERY =" from Users as o where o.mail=? and o.password=?";
		
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter(0,mail);
		query.setParameter(1,password);
		
		@SuppressWarnings("rawtypes")
		List list = query.list();

		if ((list != null) && (list.size() > 0)) {
			userFound= true;
			logger.info("user found:" + list);
		}

		session.close();
		return userFound;              
    	
		
		
    	
    	
    }


}
