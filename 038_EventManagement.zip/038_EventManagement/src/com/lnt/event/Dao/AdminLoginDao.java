package com.lnt.event.Dao;

import org.springframework.stereotype.Repository;

@Repository
public class AdminLoginDao implements IAdminLoginDao {


	

	@Override
	public int checkAdmin(String adminName, String adminPassword) {

		if (adminName.matches("abc") && adminPassword.matches("xyz")) {
			return 1;
		}
	

		return 2;
	}
}
