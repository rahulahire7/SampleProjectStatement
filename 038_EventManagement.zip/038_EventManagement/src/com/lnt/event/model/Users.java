package com.lnt.event.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author: Database_team
 * @Last-Modified:09-06-2018
 */

@Entity
@Table(name = "USERS")
public class Users implements Serializable {

	private static final long serialVersionUID = -7501137642006193668L;
	// instance variable

	@Id
	@Column(name = "user_Id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "USER_GEN")
	@SequenceGenerator(name = "USER_GEN", sequenceName = "USER_SEQ", allocationSize = 1)
	private Integer userId;

	@Column(name = "first_Name")
/*	@NotEmpty*/
	private String firstName;

	@Column(name = "last_Name")
/*	@NotEmpty(message = "last Name Required")*/
	private String lastName;

	@Column(name = "contact_Number")
/*	@NotEmpty(message = "Phone is Mandatory")*/
	private String contactNumber;

	@Column(name = "mail")
/*	@NotEmpty
	@Email(message = "please enter valid email id")*/
	private String mail;

	@Column(name = "password")
	/*@Pattern(regexp = "[1-9]\\d*")*/
	private String password;
	
	@Column(name = "address")
	/*@NotEmpty*/
	private String address;

	@Column(name = "skill_Set")
/*	@NotEmpty(message = "choose any 2")*/
	private String skillSet;
	
	@Column(name = "Event_Id")
	private Integer eventId;

	
	
		 
	@ManyToMany(targetEntity=Event.class,mappedBy="users")
	private Set<Event> events;
	
	
	public Set<Event> getEvent() {
		return events;
	}
   
	public void setEvent(Set<Event> events) {
		this.events = events;
	}

	// no-argument constructor
	public Users() {

	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	// To String method

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Users(Integer userId, String firstName, String lastName, String contactNumber,
			@Email(message = "please enter valid email id") String mail, String password, String address,
			String skillSet, Integer eventId) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber;
		this.mail = mail;
		this.password = password;
		this.address = address;
		this.skillSet = skillSet;
		this.eventId = eventId;
	}

	@Override
	public String toString() {
		return "Users [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", contactNumber="
				+ contactNumber + ", mail=" + mail + ", password=" + password + ", address=" + address + ", skillSet="
				+ skillSet + ", eventId=" + eventId + "]";
	}
	

	

	
	

	

	
	

}