package com.lnt.event.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author: Database_team
 * @Last-Modified:09-06-2018
 */

@Entity
@Table(name = "SPEAKER")
public class Speaker implements Serializable {

	private static final long serialVersionUID = -7501137642006193668L;
	// instance variable

	@Id
	@Column(name = "speaker_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SPEAKER_GEN")
	@SequenceGenerator(name = "SPEAKER_GEN", sequenceName = "SPEAKER_SEQ", allocationSize = 1)
	private Integer speakerId;

	@Column(name = "first_Name")
//	@NotEmpty
	private String firstName;

	@Column(name = "last_Name")
/*	@NotEmpty(message = "last Name Required")*/
	private String lastName;

	@Column(name = "password")
	/*@Pattern(regexp = "[1-9]\\d*")*/
	private String password;

	@Column(name = "contact_Number")
/*	@NotEmpty(message = "Phone is Mandatory")*/
	private String contactNumber;

	@Column(name = "mail")
/*	@NotEmpty
	@Email(message = "please enter valid email id")*/
	private String mail;

	@Column(name = "address")
/*	@NotEmpty*/
	private String address;

	@Column(name = "skill_Set")
	/*@NotEmpty*/
	private String skillSet;

	@Column(name = "certifications")
/*	@NotEmpty*/
	private String certifications;

	@Column(name = "Event_Id")
	private Integer eventId;

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	/*@OneToOne(cascade = CascadeType.ALL, mappedBy = "speaker")
	private Event event;*/

	public Speaker() {
		// TODO Auto-generated constructor stub
	}

	/*public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}*/

	public Integer getSpeakerId() {
		return speakerId;
	}

	public void setSpeakerId(Integer speakerId) {
		this.speakerId = speakerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getCertifications() {
		return certifications;
	}

	public void setCertifications(String certifications) {
		this.certifications = certifications;
	}

	@Override
	public String toString() {
		return "Speaker [speakerId=" + speakerId + ", firstName=" + firstName + ", lastName=" + lastName + ", password="
				+ password + ", contactNumber=" + contactNumber + ", mail=" + mail + ", address=" + address
				+ ", skillSet=" + skillSet + ", certifications=" + certifications + ", eventId=" + eventId + "]";
	}

	public Speaker(Integer speakerId, String firstName, String lastName, String password, String contactNumber,
			@Email(message = "please enter valid email id") String mail, String address, String skillSet,
			String certifications, Integer eventId) {
		super();
		this.speakerId = speakerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.contactNumber = contactNumber;
		this.mail = mail;
		this.address = address;
		this.skillSet = skillSet;
		this.certifications = certifications;
		this.eventId = eventId;
	}
	
	
}