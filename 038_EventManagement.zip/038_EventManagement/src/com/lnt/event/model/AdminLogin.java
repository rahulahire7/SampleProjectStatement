package com.lnt.event.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class AdminLogin {

	@NotEmpty
	@Size(min = 1, max = 15)
	private String adminName;
	
	
	@NotEmpty
	@Size(min = 1, max = 15)
	private String adminPassword;

	
	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}
	
	
	
}
