/**
 * 
 */
package com.lnt.event.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author 10649742
 *
 */
@Entity
@Table(name = "Event_feedback")
public class Feedback implements Serializable {

	private static final long serialVersionUID = 7183422822713247137L;

	@Id
	@Column(name = "feedback_Id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FEEDBACK_GEN")
	@SequenceGenerator(name = "FEEDBACK_GEN", sequenceName = "FEEDBACK_SEQ", allocationSize = 1)
	private Integer feedbackId;

	@Column(name = "event_Name")
	@NotEmpty
	private String eventName;

	@Column(name = "full_Name")
	private String fullName;

	@Column(name = "email_Id")
	@Email
	private String emailId;

	@Column(name = "comments")
	private String comments;

	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	public Feedback(Integer feedbackId, String eventName, String fullName, String emailId, String comments) {
		super();
		this.feedbackId = feedbackId;
		this.eventName = eventName;
		this.fullName = fullName;
		this.emailId = emailId;
		this.comments = comments;
	}

	public Integer getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", eventName=" + eventName + ", fullName=" + fullName
				+ ", emailId=" + emailId + ", comments=" + comments + "]";
	}

}
