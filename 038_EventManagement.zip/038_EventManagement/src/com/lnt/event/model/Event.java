package com.lnt.event.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "EVENT_TABLE")
public class Event implements Serializable {

	private static final long serialVersionUID = 5480323134726205204L;

	@Id
	@Column(name = "Event_Id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EVENT_GEN")
	@SequenceGenerator(name = "EVENT_GEN", sequenceName = "EVENT_SEQ", allocationSize = 1)
	private Integer eventId;

	@Column(name = "Event_Name")
	/*@NotEmpty(message = "Event Name Required")*/
	private String eventName;

	@Column(name = "Event_Date")
	//@NotEmpty(message = "Event Date Required")
	//@Past
	private String eventDate;

	@Column(name = "Event_Time")
	//@NotEmpty(message = "Event Time Required")
	private String eventTime;

	@Column(name = "Event_Place")
	//@NotEmpty(message = "Event Place Required")
	private String eventplace;

	@Column(name = "category")
	//@NotEmpty(message = "category Required")
	private String category;
	
	@Column(name = "speaker_id")
    private Integer speakerId;
	
	
	@OneToOne
	@PrimaryKeyJoinColumn
	private Speaker speaker;

	@ManyToMany(targetEntity = Users.class, cascade = CascadeType.ALL)
	@JoinTable(name = "EVENT_USER", joinColumns = @JoinColumn(name = "EVENT_ID_FK", referencedColumnName = "EVENT_ID"), 
	inverseJoinColumns = @JoinColumn(name = "USER_ID_FK", referencedColumnName = "USER_ID"))
	private Set<Users> users;

	@Column(name = "user_Id")
	private Integer userId;
	
	
	public Integer getSpeakerId() {
		return speakerId;
	}


	public void setSpeakerId(Integer speakerId) {
		this.speakerId = speakerId;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public Event() {
		super();
	}

	
	public Speaker getSpeaker() {
		return speaker;
	}

	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}

	public Set<Users> getUsers() {
		return users;
	}

	public void setUsers(Set<Users> users) {
		this.users = users;
	}
	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventDate() {
		return eventDate;
	}

	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	public String getEventplace() {
		return eventplace;
	}

	public void setEventplace(String eventplace) {
		this.eventplace = eventplace;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}


	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", eventName=" + eventName + ", eventDate=" + eventDate + ", eventTime="
				+ eventTime + ", eventplace=" + eventplace + ", category=" + category + ", speakerId=" + speakerId
				+ ", userId=" + userId + "]";
	}


	public Event(Integer eventId, String eventName, String eventDate, String eventTime, String eventplace,
			String category, Integer speakerId, Integer userId) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventTime = eventTime;
		this.eventplace = eventplace;
		this.category = category;
		this.speakerId = speakerId;
		this.userId = userId;
	}

	

}
