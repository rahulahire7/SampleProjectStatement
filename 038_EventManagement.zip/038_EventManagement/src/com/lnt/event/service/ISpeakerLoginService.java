package com.lnt.event.service;

public interface ISpeakerLoginService {
	 public boolean checkLogin(String mail, String password);
}
