package com.lnt.event.service;

public interface IAdminLoginService {
	
	public int checkAdmin(String adminName,String adminPassword);

}
