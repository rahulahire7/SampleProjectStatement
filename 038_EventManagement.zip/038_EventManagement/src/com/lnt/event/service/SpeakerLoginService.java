package com.lnt.event.service;

import javax.transaction.Transactional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.event.Dao.ISpeakerLoginDao;


@Service
public class SpeakerLoginService implements ISpeakerLoginService {

	private ISpeakerLoginDao speakerLoginDao;
	
   @Autowired
   public void setSpeakerLoginDao(ISpeakerLoginDao speakerLoginDao) {
		this.speakerLoginDao = speakerLoginDao;
	}


	
    @Override
	@Transactional
	public boolean checkLogin(String mail, String password) {
		//System.out.println("In Service class...Check Login");
		return speakerLoginDao.checkLogin(mail, password);
	}



	
}
