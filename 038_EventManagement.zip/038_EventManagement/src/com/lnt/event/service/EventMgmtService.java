/**
 * 
 */
package com.lnt.event.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.event.Dao.IEventMgmtDao;
import com.lnt.event.model.Users;

/**
 * @author 10649881
 *
 */
@Service
public class EventMgmtService implements IEventMgmtService {
	private IEventMgmtDao eventMgmtDao;

	@Autowired
	public void setUserDao(IEventMgmtDao eventMgmtDao) {
		this.eventMgmtDao = eventMgmtDao;
	}


	@Override
	@Transactional
	public void addUser(Users users) {
		this.eventMgmtDao.addUser(users);
	}
	
	
	@Override
	@Transactional
	public Users getUsersById(int userId) {
		// TODO Auto-generated method stub
		return this.eventMgmtDao.getUserById(userId);
	}

	
}
