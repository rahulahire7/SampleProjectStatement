package com.lnt.event.service;

import java.util.ArrayList;

import com.lnt.event.model.Feedback;

public interface IFeedbackService {

	public void addFeedback(Feedback feedback);

	public ArrayList<Feedback> getAllFeedback();

	public Feedback getFeedbackById(int feedbackId);

}
