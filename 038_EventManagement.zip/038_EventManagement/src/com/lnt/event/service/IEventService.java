package com.lnt.event.service;

import java.util.List;

import com.lnt.event.model.Event;
import com.lnt.event.model.Users;

public interface IEventService {
	
	public void addEvents(Event event);

	public void updateEvents(Event event);
	public List<Event> listEvents();
	public Event getEventByName(Integer eventId); //search 
	 public void removeEvent(Integer eventId);
	 public List<Users> listUsers();
}
