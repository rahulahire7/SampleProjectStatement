/**
 * 
 */
package com.lnt.event.service;

import com.lnt.event.model.Users;

/**
 * @author Backend_Team
 * Last Modified:09-06-2018
 * Module Name:EventMgmtDao
 *
 */
public interface IEventMgmtService {
	
	//Adding 
	public void addUser(Users users);
	public Users getUsersById(int userId);
}
