package com.lnt.event.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.event.Dao.IEventDao;
import com.lnt.event.model.Event;
import com.lnt.event.model.Users;

@Service
public class EventService implements IEventService {
    
	private IEventDao eventDao;
	@Autowired
	public void setEventDao(IEventDao eventDao) {
		this.eventDao = eventDao;
	}

	@Override
	@Transactional
	public void addEvents(Event event) {
		this.eventDao.addEvents(event);

	}

	@Override
	@Transactional
	public void updateEvents(Event event) {
		this.eventDao.updateEvents(event);
	}

	@Override
	@Transactional
	public List<Event> listEvents() {
		
		return this.eventDao.listEvents();
	}

	@Override
	@Transactional
	public Event getEventByName(Integer eventId) {
		
		return this.eventDao.getEventByName(eventId);
	}

	@Override
	@Transactional
	public void removeEvent(Integer eventId) {
		this.eventDao.removeEvent(eventId);
		
	}
	@Override
	@Transactional
	public List<Users> listUsers() {
		
		return this.eventDao.listUsers();

}
}