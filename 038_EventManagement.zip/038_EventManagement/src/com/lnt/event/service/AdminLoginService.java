package com.lnt.event.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.event.Dao.IAdminLoginDao;



@Service
class AdminLoginService implements IAdminLoginService {

	private IAdminLoginDao adminDao;

	
	@Autowired
	public void setAdminDao(IAdminLoginDao adminDao) {
		this.adminDao = adminDao;
	}

	@Override
	@Transactional
	public int checkAdmin(String adminName, String adminPassword) {
        return adminDao.checkAdmin(adminName, adminPassword);

	}

}
