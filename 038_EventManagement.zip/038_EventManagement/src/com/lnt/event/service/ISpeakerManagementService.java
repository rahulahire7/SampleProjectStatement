/**
 * 
 */
package com.lnt.event.service;

import java.util.List;

import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;



/**
 * @author Backend_Team
 * Last Modified:09-06-2018
 * Module Name:SpeakerManagementDao
 *
 */
public interface ISpeakerManagementService {
	
	//Adding 
	public void addSpeaker(Speaker speaker);
	public Speaker getSpeakerById(int speakerId);
/*	public List<Users> listUsers();*/
	/*public void updateUsers(Speaker p);
	public List<Speaker> listUsers();
	
	public void removeUsers(int id);*/
}
