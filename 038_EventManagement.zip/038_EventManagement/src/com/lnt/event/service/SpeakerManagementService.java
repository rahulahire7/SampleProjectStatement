/**
 * 
 */
package com.lnt.event.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.event.Dao.ISpeakerManagementDao;
import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;

/**
 * @author 10649881
 *
 */
@Service
public class SpeakerManagementService implements ISpeakerManagementService {
	private ISpeakerManagementDao speakerManagementDao;

	@Autowired
	public void setUserDao(ISpeakerManagementDao speakerManagementDao) {
		this.speakerManagementDao = speakerManagementDao;
	}


	@Override
	@Transactional
	public void addSpeaker(Speaker speaker) {
		this.speakerManagementDao.addSpeaker(speaker);
	}
	
	
	@Override
	@Transactional
	public Speaker getSpeakerById(int speakerId) {
		// TODO Auto-generated method stub
		return this.speakerManagementDao.getSpeakerById(speakerId);
	}


	/*@Override
	@Transactional
	public List<Users> listUsers() {
		
		return this.speakerManagementDao.listUsers();
	}*/

	
}
