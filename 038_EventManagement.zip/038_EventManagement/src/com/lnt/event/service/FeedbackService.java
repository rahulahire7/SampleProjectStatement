/**
 * 
 */
package com.lnt.event.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.event.Dao.IFeedbackDao;
import com.lnt.event.model.Feedback;

/**
 * @author 10649742
 *
 */
@Service
public class FeedbackService implements IFeedbackService {
	private IFeedbackDao feedbackDao;

	@Autowired
	public void setFeedbackDao(IFeedbackDao feedbackDao) {
		this.feedbackDao = feedbackDao;
	}

	@Override
	@Transactional
	public void addFeedback(Feedback feedback) {
	 
		this.feedbackDao.addFeedback(feedback);

	}

	@Override
	@Transactional
	public ArrayList<Feedback> getAllFeedback() {
		return this.feedbackDao.getAllFeedback();
	}

	@Override
	public Feedback getFeedbackById(int feedbackId) {
		// TODO Auto-generated method stub
		return this.feedbackDao.getFeedbackById(feedbackId);
	}

	

	
}
