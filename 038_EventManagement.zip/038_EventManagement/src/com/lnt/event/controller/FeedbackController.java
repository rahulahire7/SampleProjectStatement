/**
 * 
 */
package com.lnt.event.controller;

import javax.validation.Valid;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.event.model.Feedback;
import com.lnt.event.service.IFeedbackService;


/**
 * @author pracheta,prajakta
 *
 */
@Controller
@RequestMapping("/feedBack")
public class FeedbackController {

	//private static final Logger logger = LoggerFactory.getLogger(FeedbackController.class);
	private IFeedbackService feedbackService;

	@Autowired
	@Qualifier(value = "feedbackService")
	public void setFeedbackService(IFeedbackService feedbackService) {
		this.feedbackService = feedbackService;
	}

	@RequestMapping(value = "/feedbackForm", method = RequestMethod.GET)
	public String showFeedbackForm(Model model) {
		model.addAttribute("feedback", new Feedback());
		model.addAttribute("listFeedback", this.feedbackService.getAllFeedback());
		
		return "feedbackPage";
	}

	@RequestMapping(value = "/feedBackAdd", method = RequestMethod.POST)
	public String addFeedback(@ModelAttribute("feedback") @Valid Feedback feedback, BindingResult result, Model model) {
		model.addAttribute("listFeedback", this.feedbackService.getAllFeedback());
		if (result.hasErrors()) {
			return "feedbackPage";
		} else {
			this.feedbackService.addFeedback(feedback);
			//logger.info("Feedback saved ,returning success.jsp page");
			model.addAttribute("feedback", feedback);
			return "feedbackPage";
		}

	}

	@RequestMapping(value = "/feedback", method = RequestMethod.GET)
	public String listFeedback(Model model) {
	model.addAttribute("listFeedback", this.feedbackService.getAllFeedback());
		return "feedbackPage";// view name
	}

}
