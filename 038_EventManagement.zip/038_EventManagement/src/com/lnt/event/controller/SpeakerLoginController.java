package com.lnt.event.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.event.model.SpeakerLoginForm;
import com.lnt.event.service.ISpeakerLoginService;

@Controller
@RequestMapping("/speakerLogin")
public class SpeakerLoginController {
	

	private ISpeakerLoginService speakerService;
	

	
	@Autowired
		public void setSpeakerService(ISpeakerLoginService speakerService) {
		this.speakerService = speakerService;
	}


		@RequestMapping(value="/showSpeakerLogin",method = RequestMethod.GET)
		public String showSpeakerLoginForm(Map model) {
			SpeakerLoginForm loginform = new SpeakerLoginForm();
			model.put("loginform", loginform);
			return "loginSpeaker";
		}
		

		@SuppressWarnings("unchecked")
		@RequestMapping(value="/speakerLoginValidate",method = RequestMethod.POST)
		public String processForm(@ModelAttribute("loginform") @Valid SpeakerLoginForm loginform, BindingResult result,
				Map model) {

			
			/*if (result.hasErrors()) {
				return "loginSpeaker";
			}
			*/
		
			boolean userExists =speakerService.checkLogin(loginform.getMail(),
	                loginform.getPassword());
			System.out.println(userExists);
			
			if(userExists){
				model.put("loginform",loginform);
				return "speakerViewEvents";
			}else{
				/*result.rejectValue("mail","invaliduser");*/
				
				return "loginSpeaker";
			}

		}
	
		
		
		
	
}
