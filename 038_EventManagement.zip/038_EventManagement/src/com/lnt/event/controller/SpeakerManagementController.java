package com.lnt.event.controller;
/*
 * 
 * @author Backend_Team
 * Last Modified:09-06-2018
 * Module Name:SpeakerManagementDao
 *
 */

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.lnt.event.model.Speaker;
import com.lnt.event.service.ISpeakerManagementService;

@Controller
@RequestMapping("/speakerRegistration")
public class SpeakerManagementController {
	
	private ISpeakerManagementService speakerManagementService;
	@Autowired
	@Qualifier(value = "speakerManagementService")
	public void setEventMgmtService(ISpeakerManagementService speakerManagementService) {
		this.speakerManagementService = speakerManagementService;
	}

	@RequestMapping(value = "/speakersignUp", method = RequestMethod.GET)
	public String showUserForm(Model model) {
		model.addAttribute("speaker", new Speaker());
		//model.addAttribute("listUser", this.speakerManagementService.listUsers());
		return "speakerSignup";
	}
/*---------------------adding aspeaker---------------------------*/
	@RequestMapping(value = "/speakerAdd", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("loginform") 
	@Valid final Speaker speaker, final BindingResult result,
	final RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			/*logger.error("Returning userForm.jsp page");	*/

			return "speakerSignup";
				}
		speakerManagementService.addSpeaker(speaker);
		redirectAttributes.addFlashAttribute("speaker", speaker);
			return "loginSpeaker";
		
	}
	

}
