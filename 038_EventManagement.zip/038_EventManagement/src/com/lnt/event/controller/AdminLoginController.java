package com.lnt.event.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.event.model.AdminLogin;
import com.lnt.event.service.IAdminLoginService;


@Controller
@RequestMapping("/adminLogin")
public class AdminLoginController {

	private IAdminLoginService adminService;

	@Autowired
	public void setAdminService(IAdminLoginService adminService) {
		this.adminService = adminService;
	}

	@RequestMapping(value = "/ShowAdminLogin", method = RequestMethod.GET)
	public String showForm(Map model) {
		AdminLogin adminloginform = new AdminLogin();
		model.put("adminloginform", adminloginform);
		return "loginAdmin";
	}

	
	@RequestMapping(value = "/validate", method = RequestMethod.POST)
	public String processForm(@ModelAttribute("adminloginform") @Valid AdminLogin adminloginform, BindingResult result, Map model) {

		if (result.hasErrors()) {
			return "loginAdmin";
		}

		int adminExists = adminService.checkAdmin(adminloginform.getAdminName(), adminloginform.getAdminPassword());
		if (adminExists==1) {
			System.out.println("1");
			model.put("adminloginform", adminloginform);
			return "adminEventPage";
		} 
		if (adminExists==2){
			System.out.println("2");
			result.rejectValue("adminName", "invaliduser");
			return "adminerrorpage";
		}
		else {
			return "adminEventPage";
		}
	}
}
