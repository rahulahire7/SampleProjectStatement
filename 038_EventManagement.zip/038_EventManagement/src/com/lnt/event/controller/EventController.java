package com.lnt.event.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.event.model.Event;
import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;
import com.lnt.event.service.IEventService;

@Controller
@RequestMapping("/events")
public class EventController {

	private IEventService eventService;
	@Autowired
	public void setEventService(IEventService eventService) {
		this.eventService = eventService;
	}

/*	@RequestMapping(value = "/index")
	public String showhomepage(Model model) {
		return "index";
	}*/


	@RequestMapping(value = "/addNewEvent", method = RequestMethod.GET)
	public String showAdminEventPage(Model model) {
		model.addAttribute("admin", new Event());
		model.addAttribute("listUser", this.eventService.listUsers());
		return "adminEventPage";
	}

	// showEvent TABLE
	@RequestMapping(value = "/showAllEventAdded", method = RequestMethod.GET)
	public String listAllEvents(Model model) {
		model.addAttribute("admin", new Event());
		model.addAttribute("listevents", this.eventService.listEvents());

		return "viewevent";

	}

	// adding an event into the table
	@RequestMapping(value = "/admin/addevent", method = RequestMethod.POST)
	public String addEvent(@ModelAttribute("admin") @Valid Event event, BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "adminEventPage";
		} else {
			if (event.getEventId() != null) {
				this.eventService.updateEvents(event);
				model.addAttribute("listevents", this.eventService.listEvents());
				return "viewevent";
			}

			this.eventService.addEvents(event);
			model.addAttribute("listevents", this.eventService.listEvents());
			return "viewevent";
		}

	}

	// delete the record
	@RequestMapping(value = "/remove/{eventId}", method = RequestMethod.GET)
	public String removeEvent(@PathVariable("eventId") Integer eventId, Model model) {
		this.eventService.removeEvent(eventId);
		model.addAttribute("listevents", this.eventService.listEvents());
		return "viewevent";

	}

	// edit the column
	@RequestMapping(value = "/edit/{eventId}", method = RequestMethod.GET)
	public String editEvent(@PathVariable("eventId") Integer eventId, Model model) {
		model.addAttribute("admin", this.eventService.getEventByName(eventId));
		return "adminEventPage";
	}

	//redirecting the speaker name from speaker registration form to viewevents form
	@RequestMapping(value = "/loginSpeaker", method = RequestMethod.GET)
	public String showViewEvents(@ModelAttribute("speaker") 
	final Speaker speaker,final Model model)
	{
		model.addAttribute("speaker", speaker);
		ArrayList<Event> eventList = (ArrayList<Event>) eventService.listEvents();
		model.addAttribute("eventList", eventList);
		return "adminviewEvent";
		//it should show before speaker register for the page
	}
	@RequestMapping(value = "/speaker/participants_list", method = RequestMethod.GET)
	public String listAllUsers(Model model,Users user)
	{
		model.addAttribute("user", user);
		List<Users> listUser=this.eventService.listUsers();
		model.addAttribute("listUser", listUser);
		return "showUserList";
		
	}
}
