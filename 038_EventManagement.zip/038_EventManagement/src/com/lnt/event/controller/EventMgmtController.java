package com.lnt.event.controller;
/*
 * 
 * @author Backend_Team
 * Last Modified:09-06-2018
 * Module Name:EventMgmtDao
 *
 */

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.event.model.Speaker;
import com.lnt.event.model.Users;
import com.lnt.event.service.IEventMgmtService;



@Controller
@RequestMapping("/Registration")
public class EventMgmtController {
	private IEventMgmtService eventMgmtService;

	@Autowired
	public void setEventMgmtService(IEventMgmtService eventMgmtService) {
		this.eventMgmtService = eventMgmtService;
	}

	@RequestMapping(value = "/participantsignUp", method = RequestMethod.GET)
	public String showParticipantForm(Model model) {
		model.addAttribute("users", new Users());
		return "participantSignup";
	}
	

	/*@RequestMapping(value = "/speakersignUp", method = RequestMethod.GET)
	public String showSpeakerForm(Model model) {
		model.addAttribute("Speakers", new Speaker());
		return "speakerSignup";
	}*/
	@RequestMapping(value = "/participantadd", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("users") 
	@Valid Users user, BindingResult result) {
		/*if(result.hasErrors()) {
			//logger.error("Returning userForm.jsp page");	

			return "loginParticipant";
				}*/
		
			this.eventMgmtService.addUser(user);
			
			return "loginParticipant";
		
	}

}
