

drop sequence customer_SEQ;
CREATE SEQUENCE customer_SEQ 
START WITH 10
INCREMENT BY 1;
drop table tour_customer;

drop sequence TOUR_SEQ;
CREATE SEQUENCE TOUR_SEQ 
START WITH 1
INCREMENT BY 1;

drop table Travel;
create table Travel(tour_id NUMBER, 
location VARCHAR2(30),
member_type VARCHAR2(20),
cost_per_person NUMBER(10,2),
max_person NUMBER,
estimated_start_date DATE,
estimated_end_date DATE,
hotel VARCHAR2(30),
  CONSTRAINT Travel_pk PRIMARY KEY (tour_id)
);





insert into Travel values(TOUR_SEQ.nextval,'Goa','couple',5000,2,'08-JUL-18','15-JUL-18' , 'Hotel residency');
insert into Travel values(TOUR_SEQ.nextval,'Goa','family',10000,15,'08-AUG-18' ,'20-AUG-18' , 'Hotel Sun & Sand');
insert into Travel values(TOUR_SEQ.nextval,'Goa','couple',8000,2,'05-DEC-18' ,'13-DEC-18' , 'Hotel Fountain');
insert into Travel values(TOUR_SEQ.nextval,'Goa','friends',20000,10,'01-JAN-19' ,'07-JAN-19' , 'Hotel Sun & Sand');
insert into Travel values(TOUR_SEQ.nextval,'Goa','family',13000,15,'12-NOV-18' ,'18-NOV-18' , 'Hotel Castle');

insert into Travel values(TOUR_SEQ.nextval,'Mumbai','couple',9000,2,'10-AUG-18' ,'17-AUG-18' , 'Hotel elite inn');
insert into Travel values(TOUR_SEQ.nextval,'Mumbai','family',40000,15,'06-AUG-18' ,'10-AUG-18' , 'Hotel elite inn');
insert into Travel values(TOUR_SEQ.nextval,'Mumbai','friends',10000,10,'06-OCT-18' ,'10-OCT-18' , 'Hotel Paradise');
insert into Travel values(TOUR_SEQ.nextval,'Mumbai','family',30000,15,'25-DEC-18' ,'31-DEC-18' , 'Hotel Oberoi');
insert into Travel values(TOUR_SEQ.nextval,'Mumbai','couple',8000,2,'10-JUL-18' ,'16-JUL-18' , 'Hotel elite inn');


insert into Travel values(TOUR_SEQ.nextval,'Nainital','couple',14000,2,'21-SEP-18','28-SEP-18' , 'Hotel Ashoka');
insert into Travel values(TOUR_SEQ.nextval,'Nainital','family',58000,15,'22-SEP-18','29-SEP-18' , 'Hotel Ashoka');
insert into Travel values(TOUR_SEQ.nextval,'Nainital','couple',12000,2,'21-APR-19','25-APR-18' , 'Hotel Royal');
insert into Travel values(TOUR_SEQ.nextval,'Nainital','family',50000,15,'20-NOV-18','27-NOV-18' , 'Hotel Rajwada');
insert into Travel values(TOUR_SEQ.nextval,'Nainital','friends',34000,10,'11-OCT-18','19-OCT-18' , 'Hotel Center Point');


insert into Travel values(TOUR_SEQ.nextval,'Shimla','couple',15000,2,'16-SEP-18' ,'21-SEP-18' , 'Hotel TAJ');
insert into Travel values(TOUR_SEQ.nextval,'Shimla','couple',18000,2,'22-FEB-19' ,'28-FEB-19' , 'Hotel Radisson Blue');
insert into Travel values(TOUR_SEQ.nextval,'Shimla','family',49000,15,'02-AUG-18' ,'06-AUG-18' , 'Hotel Center Point');
insert into Travel values(TOUR_SEQ.nextval,'Shimla','friends',36000,10,'18-DEC-18' ,'24-DEC-18' , 'Hotel Richards');
insert into Travel values(TOUR_SEQ.nextval,'Shimla','friends',34000,10,'16-NOV-18' ,'21-NOV-18' , 'Hotel TAJ');


insert into Travel values(TOUR_SEQ.nextval,'Rajasthan','friends',12000,10,'08-AUG-18' ,'18-AUG-18' , 'Hotel Amrut');
insert into Travel values(TOUR_SEQ.nextval,'Rajasthan','family',19000,15,'18-OCT-18' ,'24-OCT-18' , 'Hotel Raj');
insert into Travel values(TOUR_SEQ.nextval,'Rajasthan','couple',7000,2,'26-NOV-18' ,'01-DEC-18' , 'Hotel Amrut');


insert into Travel values(TOUR_SEQ.nextval,'Manali','couple',13000,2,'25-NOV-18' ,'01-DEC-18' , 'Hotel Bluemoon');
insert into Travel values(TOUR_SEQ.nextval,'Manali','couple',16000,2,'25-DEC-18' ,'30-DEC-18' , 'Hotel Tuli');
insert into Travel values(TOUR_SEQ.nextval,'Manali','family',29000,15,'14-OCT-18' ,'18-OCT-18' , 'Hotel Bluemoon');
insert into Travel values(TOUR_SEQ.nextval,'Manali','friends',22000,10,'07-SEP-18' ,'11-SEP-18' , 'Hotel Tuli Imperial');


insert into Travel values(TOUR_SEQ.nextval,'Kashmir','family',10000,15,'02-MAR-19' ,'08-MAR-19' , 'Hotel Heaven');
insert into Travel values(TOUR_SEQ.nextval,'Kashmir','friends',10000,10,'02-FEB-19' ,'08-FEB-19' , 'Hotel Sunrise');
insert into Travel values(TOUR_SEQ.nextval,'Kashmir','couple',10000,2,'05-APR-19' ,'10-APR-19' , 'Hotel Seawood');
insert into Travel values(TOUR_SEQ.nextval,'Kashmir','family',10000,15,'11-MAR-19' ,'18-MAR-19' , 'Hotel Heaven');

insert into Travel values(TOUR_SEQ.nextval,'Kerela','couple',10000,2,'05-APR-19' ,'10-APR-19' , 'Hotel Antilla');
insert into Travel values(TOUR_SEQ.nextval,'Kerela','family',60000,15,'10-NOV-18' ,'16-NOV-18' , 'Hotel Le Meridian');



select * from travel where location='Goa';
select * from travel;

create table tour_customer(
customer_id NUMBER PRIMARY KEY ,
tour_id NUMBER, 
customer_name VARCHAR2(30),
customer_email VARCHAR2(50),
phone_number NUMBER(13),
no_of_person NUMBER,
CONSTRAINT fk_travel
    FOREIGN KEY (tour_id)
    REFERENCES Travel(tour_id)
);

insert into tour_customer values(customer_SEQ.nextval,1,'Smita','smita@gmail.com',9879879876,2);
select * from tour_customer;


