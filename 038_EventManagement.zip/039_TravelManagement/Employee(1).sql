create table Employee(
emp_id NUMBER,
emp_name VARCHAR2(30) NOT NULL,
password VARCHAR2(30),
emp_type VARCHAR2(30),
emp_designation VARCHAR2(30)
);

create sequence EMP_SEQ
MINVALUE 1001
MAXVALUE 9999
  START WITH 1001
  INCREMENT BY 1;
  
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Rahul', 'user1001','Non moving','Manager');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Nihar', 'user1002','Non moving','Clerk');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Rama', 'user1003','Non moving','Clerk');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Sarvesh', 'user1004','Moving','Driver');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Shyam', 'user1005','Moving','Driver');

  select * from Employee;