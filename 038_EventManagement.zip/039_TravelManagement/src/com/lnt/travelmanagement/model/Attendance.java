package com.lnt.travelmanagement.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="attendance")
public class Attendance implements Serializable{

	private static final long serialVersionUID = 2336568231458576220L;

	@Id
	@Column(name="emp_id")
	private Integer empId;
	
	@Column(name="present_days")
	private Integer presentDays;
	
	@Column(name="month")
	private String month;
	
	@Column(name="emp_salary")
	private Integer salaryPerDay;
	

	@Column(name="total_salary")
	private Integer totalSalary;

	/**
	 * @return the empId
	 */
	public Integer getEmpId() {
		return empId;
	}

	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	/**
	 * @return the presentDays
	 */
	public Integer getPresentDays() {
		return presentDays;
	}

	/**
	 * @param presentDays the presentDays to set
	 */
	public void setPresentDays(Integer presentDays) {
		this.presentDays = presentDays;
	}



	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the totalSalary
	 */
	public Integer getTotalSalary() {
		return totalSalary;
	}

	/**
	 * @param totalSalary the totalSalary to set
	 */
	public void setTotalSalary(Integer totalSalary) {
		this.totalSalary = totalSalary;
	}

	/**
	 * @return the salaryPerDay
	 */
	public Integer getSalaryPerDay() {
		return salaryPerDay;
	}

	/**
	 * @param salaryPerDay the salaryPerDay to set
	 */
	public void setSalaryPerDay(Integer salaryPerDay) {
		this.salaryPerDay = salaryPerDay;
	}

	public Attendance() {
		super();
	}

	public Attendance(Integer empId, Integer presentDays, String month, Integer salaryPerDay, Integer totalSalary) {
		super();
		this.empId = empId;
		this.presentDays = presentDays;
		this.month = month;
		this.salaryPerDay = salaryPerDay;
		this.totalSalary = totalSalary;
	}

	@Override
	public String toString() {
		return "Attendance [empId=" + empId + ", presentDays=" + presentDays + ", month=" + month + ", salaryPerDay="
				+ salaryPerDay + ", totalSalary=" + totalSalary + "]";
	}

	

}
