package com.lnt.travelmanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "hotels")
public class Hotel implements Serializable {

	private static final long serialVersionUID = -320053424155529219L;

	@Id
	@Column(name = "hotel_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HOTEL_GEN")
	@SequenceGenerator(name = "HOTEL_GEN", sequenceName = "HOTEL_SEQ", allocationSize = 1)
	private Integer hotelId;

	@Column(name = "hotel_name")
	private String hotelName;

	@NotEmpty
	@Column(name = "hotel_location")
	private String location;

	@Column(name = "hotel_ratings")
	private String ratings;

	@Column(name = "hotel_contact_no")
	private Long contactNo;

	@Column(name = "hotel_address")
	private String address;

	@Column(name = "hotel_facility")
	private String facility;

	@Column(name = "hotel_meals")
	private String meals;

	@Column(name = "hotel_pickup")
	private String pickup;

	@Column(name = "hotel_drop")
	private String drop;

	public Hotel() {
		super();
	}

	public Integer getHotelId() {
		return hotelId;
	}

	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRatings() {
		return ratings;
	}

	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	public Long getContactNo() {
		return contactNo;
	}

	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getPickup() {
		return pickup;
	}

	public void setPickup(String pickup) {
		this.pickup = pickup;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

	public Hotel(Integer hotelId, String hotelName, String location, String ratings, Long contactNo, String address,
			String facility, String meals, String pickup, String drop) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.ratings = ratings;
		this.contactNo = contactNo;
		this.address = address;
		this.facility = facility;
		this.meals = meals;
		this.pickup = pickup;
		this.drop = drop;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", location=" + location + ", ratings="
				+ ratings + ", contactNo=" + contactNo + ", address=" + address + ", facility=" + facility + ", meals="
				+ meals + ", pickup=" + pickup + ", drop=" + drop + "]";
	}

}
