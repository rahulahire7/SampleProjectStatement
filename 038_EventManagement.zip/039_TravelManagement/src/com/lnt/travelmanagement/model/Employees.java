/**
 * 
 */
package com.lnt.travelmanagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * @author 10649708
 *
 */
@Entity
@Table(name="Employee")
@Inheritance(strategy=InheritanceType.JOINED)
public class Employees {
	@Id
	@Column(name = "emp_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EMP_GEN")
	@SequenceGenerator(name = "EMP_GEN", sequenceName = "EMP_SEQ", allocationSize = 1)
	@NotNull(message="please enter user id")
	private Integer empId;

	
	@Column(name = "emp_name")
	
	private String empName;

	/**
	 * @return the designation
	 */

	@Column(name = "password")
	@NotNull(message="please enter user password")
	private String empPassword;

	@Column(name = "emp_type")
	private String empType;

	@Column(name = "emp_designation")
	private String designation;

	public Employees() {
		// TODO Auto-generated constructor stub
	}

	public Employees(Integer empId, String empName, String empPassword, String empType, String designation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empPassword = empPassword;
		this.empType = empType;
		this.designation = designation;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employees [empId=" + empId + ", empName=" + empName + ", empPassword=" + empPassword + ", empType="
				+ empType + ", designation=" + designation + "]";
	}

}
