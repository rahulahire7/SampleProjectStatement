package com.lnt.travelmanagement.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TOUR_CUSTOMER")
public class TourCustomer implements Serializable {
	private static final long serialVersionUID = -8400167276330669112L;

	@Id
	@Column(name = "customer_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Customer_GEN")
	@SequenceGenerator(name = "Customer_GEN", sequenceName = "Customer_SEQ", allocationSize = 1)
	private Integer customerId;

	@Column(name = "tour_id")
	private Integer tourId;

	@Column(name = "customer_name")
	private String customerName;

	@Column(name = "customer_email")
	private String email;

	@Column(name = "phone_number")
	private Long phoneNumber;
	
	@Column(name = "no_of_person")
	private Integer noOfPerson;

	
	@Column(name = "amount")
	private Double amount;

	public TourCustomer() {
		super();

	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	

	public Integer getTourId() {
		return tourId;
	}

	public void setTourId(Integer tourId) {
		this.tourId = tourId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getNoOfPerson() {
		return noOfPerson;
	}

	public void setNoOfPerson(Integer noOfPerson) {
		this.noOfPerson = noOfPerson;
	}

	public TourCustomer(Integer customerId, Integer tourId, String customerName, String email, Long phoneNumber,
			Integer noOfPerson, Double amount) {
		super();
		this.customerId = customerId;
		this.tourId = tourId;
		this.customerName = customerName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.noOfPerson = noOfPerson;
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "TourCustomer [customerId=" + customerId + ", tourId=" + tourId + ", customerName=" + customerName
				+ ", email=" + email + ", phoneNumber=" + phoneNumber + ", noOfPerson=" + noOfPerson + ", amount="
				+ amount + "]";
	}


}