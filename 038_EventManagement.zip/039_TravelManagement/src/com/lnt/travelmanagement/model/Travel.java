/**
 * 
 */
package com.lnt.travelmanagement.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

/**
 * @author 10649846
 *
 */
@Entity
@Table(name = "Travel")
public class Travel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8151792988521917777L;

	@Id
	@Column(name = "tour_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TOUR_GEN")
	@SequenceGenerator(name = "TOUR_GEN", sequenceName = "TOUR_SEQ", allocationSize = 1)
	private Integer tourId;

	@Column(name = "location")
	private String toLocation;

	
	@Column(name = "hotel")
	private String hotel;

	@Column(name = "member_type")
	@Size(min = 5, max = 10)
	private String type;

	@Column(name = "cost_per_person")
	private Double costPerPerson;
	
	@Column(name = "max_person")
	private Integer maxPerson;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "estimated_start_date")
	private Date estimatedStartDate;

	@Temporal(TemporalType.DATE)
	@Column(name = "estimated_end_date")
	private Date estimatedendDate;
	
	public Travel() {

	}

	public Date getEstimatedStartDate() {
		return estimatedStartDate;
	}

	public void setEstimatedStartDate(Date estimatedStartDate) {
		this.estimatedStartDate = estimatedStartDate;
	}

	public Date getEstimatedendDate() {
		return estimatedendDate;
	}

	public void setEstimatedendDate(Date estimatedendDate) {
		this.estimatedendDate = estimatedendDate;
	}

	public Integer getTourId() {
		return tourId;
	}

	public void setTourId(Integer tourId) {
		this.tourId = tourId;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}



	public String getHotel() {
		return hotel;
	}

	public void setHotel(String hotel) {
		this.hotel = hotel;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	

	public Double getCostPerPerson() {
		return costPerPerson;
	}

	public void setCostPerPerson(Double costPerPerson) {
		this.costPerPerson = costPerPerson;
	}

	public Integer getMaxPerson() {
		return maxPerson;
	}

	public void setMaxPerson(Integer maxPerson) {
		this.maxPerson = maxPerson;
	}

	public Travel(Integer tourId, String toLocation, String hotel, String type, Double costPerPerson, Integer maxPerson,
			Date estimatedStartDate, Date estimatedendDate) {
		super();
		this.tourId = tourId;
		this.toLocation = toLocation;
		this.hotel = hotel;
		this.type = type;
		this.costPerPerson = costPerPerson;
		this.maxPerson = maxPerson;
		this.estimatedStartDate = estimatedStartDate;
		this.estimatedendDate = estimatedendDate;
	}

	@Override
	public String toString() {
		return "Travel [tourId=" + tourId + ", toLocation=" + toLocation + ", hotel=" + hotel + ", type=" + type
				+ ", costPerPerson=" + costPerPerson + ", maxPerson=" + maxPerson + ", estimatedStartDate="
				+ estimatedStartDate + ", estimatedendDate=" + estimatedendDate + "]";
	}

	
}
