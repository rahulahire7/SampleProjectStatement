package com.lnt.travelmanagement;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "hotels")
public class Hotel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "hotel_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "HOTEL_GEN")
	@SequenceGenerator(name = "HOTEL_GEN", sequenceName = "HOTEL_GEN", allocationSize = 1)
	private int hotelId;

	@Column(name = "hotel_name")
	private String hotelName;

	@Column(name = "hotel_location")
	private String location;

	@Column(name = "hotel_ratings")
	private String ratings;

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRatings() {
		return ratings;
	}

	public void setRatings(String ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", location=" + location + ", ratings="
				+ ratings + "]";
	}

	public Hotel(int hotelId, String hotelName, String location, String ratings) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.location = location;
		this.ratings = ratings;
	}

	public Hotel() {
		super();
	}

}
