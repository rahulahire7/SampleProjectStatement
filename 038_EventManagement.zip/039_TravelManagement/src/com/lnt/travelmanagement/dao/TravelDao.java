/**
 * 
 */
package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.travelmanagement.model.Travel;

@Repository
public class TravelDao implements ITravelDao {

	private static final Logger logger = LoggerFactory.getLogger(TravelDao.class);
	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Travel> searchByLocation(String location) {
		
		

			Session session = sessionFactory.getCurrentSession();
			String hql="FROM Travel t WHERE t.toLocation=:loc";
			Query query = session.createQuery(hql);
			query.setParameter("loc", location);
			//System.out.println(location);
			ArrayList<Travel> travelList = (ArrayList<Travel>)query.list();
			for (Travel t : travelList) {
				logger.info("Packages available are: ::" +t);
			}
			return travelList;
		
		
	}
	
	public Travel getPackageById(int tourId) {
		Session session = this.sessionFactory.getCurrentSession();
		Travel t = (Travel) session.load(Travel.class, new Integer(tourId));
		logger.info("Package  details=" +t);
		return t;
	}

	
	@Override
	public Integer checkAvailableSeats(Integer noOfPerson) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		return null;
	}

	@Override
	public Double getPackageAmount(Integer tourId) {
		Session session = sessionFactory.getCurrentSession();
		String hql="Select costPerPerson FROM Travel t WHERE t.tourId=:tour_id";
		Query query = session.createQuery(hql);
		query.setParameter("tour_id", tourId);
		Double amount=(Double) query.uniqueResult();
		return amount;
	}

	
	

}
