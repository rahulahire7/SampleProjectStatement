package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.travelmanagement.model.Employees;

@Repository
public class AttendanceDao implements IAttendanceDao{
	
	private static final Logger logger =LoggerFactory.getLogger(AttendanceDao.class);
	private SessionFactory sessionFactory;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		logger.info("Session Factory ...."+sessionFactory);
	}
	@Override
	public void updateAttendance(Integer empId) {
		Session session = sessionFactory.getCurrentSession();
		
		String hql = "update Attendance a set a.presentDays=a.presentDays+1, a.totalSalary= a.totalSalary+2500 where a.empId =:emp_id";
		Query query = session.createQuery(hql);	
		query.setParameter("emp_id",empId);
		int rs=query.executeUpdate();
	
		
		if (rs>0) {
			logger.info("attendance updated");
		}
		//session.close();
	}
	@Override
	public ArrayList<Employees> listAllEmployee() {
		
		Session session = sessionFactory.getCurrentSession();
		String hql="from Employees";
		Query query = session.createQuery(hql);	
		@SuppressWarnings("unchecked")
		ArrayList<Employees> list=(ArrayList<Employees>) query.list();
		//session.close();
		System.out.println(list);
		return list;
	}	
	

}
