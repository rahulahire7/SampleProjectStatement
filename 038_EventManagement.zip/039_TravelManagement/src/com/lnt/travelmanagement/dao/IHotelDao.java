package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Hotel;

public interface IHotelDao {

	

	public ArrayList<Hotel> getHotelByLoc(String location);
	
}
