/**
 * 
 */
package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Travel;

/**
 * @author 10649846
 *
 */


public interface ITravelDao {

	public ArrayList<Travel> searchByLocation(String location);

	public Integer checkAvailableSeats(Integer noOfPerson);
	
	public Travel getPackageById(int tourId);

	public Double getPackageAmount(Integer tourId);
	
	
}
