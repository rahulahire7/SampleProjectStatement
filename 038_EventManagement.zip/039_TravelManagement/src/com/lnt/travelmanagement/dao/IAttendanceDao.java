package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Employees;

public interface IAttendanceDao {
	public void updateAttendance(Integer empId);

	public ArrayList<Employees> listAllEmployee();


}
