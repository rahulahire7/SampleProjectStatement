package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.travelmanagement.model.TourCustomer;

@Repository
public class TourCustomerDao implements ITourCustomerDao {

	private static final Logger logger = LoggerFactory.getLogger(TourCustomerDao.class);

	private SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addTourCustomer(TourCustomer tc) {

		Session session = this.sessionFactory.getCurrentSession();
		session.persist(tc);
		logger.info("Tour customer saved successfully, Customer Details=" + tc);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<TourCustomer> listTourCustomer() {

		Session session = this.sessionFactory.getCurrentSession();
		ArrayList<TourCustomer> tourCustomerList = (ArrayList<TourCustomer>) session.createQuery("from TourCustomer")
				.list();
		for (TourCustomer hc : tourCustomerList) {
			logger.info("Tour Customer List::" + hc);

		}
		return tourCustomerList;
	}

	@Override
	public TourCustomer getTourCustomer(Integer tourId) {
		Session session = this.sessionFactory.getCurrentSession();
		TourCustomer tourCustomer = (TourCustomer) session.load(TourCustomer.class, tourId);

		logger.info("Tour Customer ::" + tourCustomer);
		return tourCustomer;
	}

	@Override
	public TourCustomer getCustomerById(Integer customerId) {
		Session session = this.sessionFactory.getCurrentSession();
		TourCustomer customer = (TourCustomer) session.load(TourCustomer.class, customerId);
		return customer;
	}

	@Override
	public void updateTotalAmount(Integer customerId, Double amount, Integer noOfPerson) {
		Session session = this.sessionFactory.getCurrentSession();
		if(noOfPerson!=2) {
			String hql = "UPDATE TourCustomer tc set tc.amount = :amount*:no_of_person " + "WHERE customerId = :customer_id";
			Query query = session.createQuery(hql);
			query.setParameter("customer_id",customerId);
			query.setParameter("no_of_person", noOfPerson);
			query.setParameter("amount", amount);
			
			int result = query.executeUpdate();
			if (result>0) {
				logger.info("amount updates");
			}
		}
		

	}
}
