package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.travelmanagement.model.Hotel;

@Repository
public class HotelDao implements IHotelDao {

	private static final Logger logger =LoggerFactory.getLogger(HotelDao.class);
	private SessionFactory sessionFactory;
	//private SessionFactory sessionFactory=HibernateUtil.getSessionFactory();

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		logger.info("Session Factory ...."+sessionFactory);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Hotel> getHotelByLoc(String location) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "FROM Hotel h WHERE h.location =:location_value";
		Query query = session.createQuery(hql);
		query.setParameter("location_value",location);
		ArrayList<Hotel> hotelList = (ArrayList<Hotel>) query.list();
		//ArrayList<Hotel> hotelList= (ArrayList<Hotel>) session.createCriteria("from Hotel h where h.location="+location).list();
		//ArrayList<Hotel> hotelList =(ArrayList<Hotel>) session.get(Hotel.class,location);
		for (Hotel h : hotelList) {
			logger.info("hotelList::" + h);
		}
		return hotelList;
	}

}
