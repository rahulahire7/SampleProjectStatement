package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Attendance;
import com.lnt.travelmanagement.model.Employees;
import com.lnt.travelmanagement.model.TourCustomer;

public interface IEmployeeLoginDao {
	public String checkEmployeeLogin(Integer empId, String empPassword);

	public int updateAttendance(Integer empId);

	public ArrayList<Employees> listAllEmployee();

	public ArrayList<TourCustomer> listAllCustomer();

	public ArrayList<Attendance> listAllAttendance();
	
}
