package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.travelmanagement.model.Attendance;
import com.lnt.travelmanagement.model.Employees;
import com.lnt.travelmanagement.model.TourCustomer;

@Repository
public class EmployeeLoginDao implements IEmployeeLoginDao {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeLoginDao.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public String checkEmployeeLogin(Integer empId, String empPassword) {
		logger.info("Entered");
		Session session = sessionFactory.getCurrentSession();
		// Query using Hibernate Query Language
		String sql = "from Employees as e where e.empId=:emp_id and e.empPassword=:password";
		Query query = session.createQuery(sql);
		query.setParameter("emp_id", empId);
		query.setParameter("password", empPassword);

		logger.info("empId of form" + empId);
		logger.info("empPassword of form" + empPassword);

		@SuppressWarnings("unchecked")
		ArrayList<Employees> list = (ArrayList<Employees>) query.list();
		String designation = null;
		if (list != null) {
			for (Employees employees : list) {
				designation = employees.getDesignation();
			}
			
		}
		return designation;
	}

	@Override
	public int updateAttendance(Integer empId) {
		Session session = sessionFactory.getCurrentSession();
		logger.info("emp id is: " + empId);
		String sql1 = "UPDATE Attendance set presentDays = presentDays+1,totalSalary=(presentDays+1)*salaryPerDay, month=to_char(sysdate,'DDMMYYYY')"
				+ "WHERE empId = :emp_id AND month!=to_char(sysdate,'DDMMYYYY')";
		Query query = session.createQuery(sql1);
		query.setParameter("emp_id", empId);
		int result = query.executeUpdate();
		return result;

	}

	@Override
	public ArrayList<Employees> listAllEmployee() {

		Session session = sessionFactory.getCurrentSession();
		String hql = "from Employees";
		Query query = session.createQuery(hql);
		@SuppressWarnings("unchecked")
		ArrayList<Employees> list = (ArrayList<Employees>) query.list();
		//
		System.out.println(list);
		return list;
	}

	@Override
	public ArrayList<TourCustomer> listAllCustomer() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from TourCustomer";
		Query query = session.createQuery(hql);
		@SuppressWarnings("unchecked")
		ArrayList<TourCustomer> list = (ArrayList<TourCustomer>) query.list();
		//
		System.out.println(list);
		return list;
	}

	@Override
	public ArrayList<Attendance> listAllAttendance() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "from Attendance";
		Query query = session.createQuery(hql);
		@SuppressWarnings("unchecked")
		ArrayList<Attendance> list = (ArrayList<Attendance>) query.list();
		//
		System.out.println(list);
		return list;

	}

}
