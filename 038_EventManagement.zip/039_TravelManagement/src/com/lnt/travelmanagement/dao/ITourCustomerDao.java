package com.lnt.travelmanagement.dao;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.TourCustomer;

public interface ITourCustomerDao {
	public void addTourCustomer(TourCustomer tc);

	public ArrayList<TourCustomer> listTourCustomer();

	public TourCustomer getTourCustomer(Integer tourId);

	public TourCustomer getCustomerById(Integer customerId);

	public void updateTotalAmount(Integer customerId, Double amount, Integer noOfPerson);
	
	
}
