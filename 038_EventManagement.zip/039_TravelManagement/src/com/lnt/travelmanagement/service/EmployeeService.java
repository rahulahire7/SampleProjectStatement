/**
 * 
 */
package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.travelmanagement.dao.IEmployeeLoginDao;
import com.lnt.travelmanagement.model.Attendance;
import com.lnt.travelmanagement.model.Employees;
import com.lnt.travelmanagement.model.TourCustomer;

/**
 * @author 10649845
 *
 */
@Service
public class EmployeeService implements IEmployeeService {
	 
	 private IEmployeeLoginDao employeeLoginDao;

	 @Autowired
	 public void setEmployeeDao(IEmployeeLoginDao employeeDao) {
			this.employeeLoginDao = employeeDao;
		}

	 
	@Override
	@Transactional
	public String checkEmployeeLogin(Integer empId, String empPassword) {
		 return employeeLoginDao.checkEmployeeLogin(empId, empPassword);
		
	
	}


	@Override
	@Transactional
	public int updateAttendance(Integer empId) {
		return employeeLoginDao.updateAttendance(empId);
		
	}


	@Override
	@Transactional
	public ArrayList<Employees> listAllEmployee() {
		// TODO Auto-generated method stub
		return employeeLoginDao.listAllEmployee();
	}


	@Override
	@Transactional
	public ArrayList<TourCustomer> listAllCustomer() {
		// TODO Auto-generated method stub
		return employeeLoginDao.listAllCustomer();
	}


	@Override
	@Transactional
	public ArrayList<Attendance> listAllAttendance() {
		// TODO Auto-generated method stub
		return employeeLoginDao.listAllAttendance();
	}

	
}
