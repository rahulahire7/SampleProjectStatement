package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Hotel;

public interface IHotelService {
	
	public  ArrayList<Hotel> getHotelByLoc(String location);
	
}
