package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.Employees;

public interface IAttendanceService {
	public void updateAttendance(Integer empId);

	public ArrayList<Employees> listAllEmployee();

}
