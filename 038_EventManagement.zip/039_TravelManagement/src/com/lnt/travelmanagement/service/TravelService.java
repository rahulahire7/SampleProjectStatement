/**
 * 
 */
package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.travelmanagement.dao.ITravelDao;
import com.lnt.travelmanagement.model.Travel;

/**
 * @author 10649846
 *
 */
@Service
public class TravelService implements ITravelService {
	
	private ITravelDao travelDao;
	@Autowired
	public void setTravelDao(ITravelDao travelDao) {
		this.travelDao = travelDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.lnt.travelmanagement.service.ITravelService#searchByLocation(java.lang.
	 * String, java.util.Date, java.util.Date)
	 */
	@Override
	@Transactional
	public ArrayList<Travel> searchByLocation(String location) {
		// TODO Auto-generated method stub
		return travelDao.searchByLocation(location);
	}

	@Override
	public Integer checkAvailableSeats(Integer noOfPerson) {
		
		return travelDao.checkAvailableSeats(noOfPerson);
	}

	@Override
	public Travel getPackageById(int tourId) {
		// TODO Auto-generated method stub
		return travelDao.getPackageById(tourId);
	}

	@Override
	public Double getPackageAmount(Integer tourId) {
		
		return travelDao.getPackageAmount(tourId);
	}

}
