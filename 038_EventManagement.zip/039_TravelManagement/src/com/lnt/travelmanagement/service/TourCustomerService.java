package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.travelmanagement.dao.ITourCustomerDao;
import com.lnt.travelmanagement.model.TourCustomer;

@Service
public class TourCustomerService implements ITourCustomerService {

	private ITourCustomerDao tourCustomerDao;

	public ITourCustomerDao getTourCustomerDao() {
		return tourCustomerDao;
	}

	@Autowired
	public void setTourCustomerDao(ITourCustomerDao tourCustomerDao) {
		this.tourCustomerDao = tourCustomerDao;
	}

	@Override
	@Transactional
	public void addTourCustomer(TourCustomer tc) {

		tourCustomerDao.addTourCustomer(tc);

	}

	@Override
	@Transactional
	public ArrayList<TourCustomer> listTourCustomer() {

		return tourCustomerDao.listTourCustomer();
	}

	@Override
	@Transactional
	public TourCustomer getTourCustomer(Integer tourId) {
		// TODO Auto-generated method stub
		return tourCustomerDao.getTourCustomer(tourId);
	}

	@Override
	@Transactional
	public TourCustomer getCustomerById(Integer customerId) {
		// TODO Auto-generated method stub
		return tourCustomerDao.getCustomerById(customerId);
	}

	@Override
	@Transactional
	public void updateTotalAmount(Integer customerId, Double amount, Integer noOfPerson) {
		// TODO Auto-generated method stub
		tourCustomerDao.updateTotalAmount(customerId,amount,noOfPerson);
	}

}
