package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.travelmanagement.dao.IHotelDao;
import com.lnt.travelmanagement.model.Hotel;

@Service
public class HotelService implements IHotelService {

	private IHotelDao hotelDao;

	@Autowired
	public void setHotelDao(IHotelDao hotelDao) {
		this.hotelDao = hotelDao;
	}
	
	
	@Override
	@Transactional
	public ArrayList<Hotel> getHotelByLoc(String location) {
		return hotelDao.getHotelByLoc(location);
	}
}
