package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.travelmanagement.dao.IAttendanceDao;
import com.lnt.travelmanagement.model.Employees;

@Service
public class AttendanceService implements IAttendanceService {
	
	
	@Autowired
	private IAttendanceDao attendanceDao;

	public void setAttendanceDao(IAttendanceDao attendanceDao) {
		this.attendanceDao = attendanceDao;
	}



	@Override
	@Transactional
	public void updateAttendance(Integer empId) {
		attendanceDao.updateAttendance(empId);
	}



	@Override
	@Transactional
	public ArrayList<Employees> listAllEmployee() {
		// TODO Auto-generated method stub
		return attendanceDao.listAllEmployee();
	}



	
}
