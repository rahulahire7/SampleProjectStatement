package com.lnt.travelmanagement.service;

import java.util.ArrayList;

import com.lnt.travelmanagement.model.TourCustomer;

public interface ITourCustomerService {

	public void addTourCustomer(TourCustomer tc);

	public ArrayList<TourCustomer> listTourCustomer();

	public TourCustomer getTourCustomer(Integer tourId);

	public TourCustomer getCustomerById(Integer customerId);

	public void updateTotalAmount(Integer customerId, Double amount, Integer noOfPerson);
}
