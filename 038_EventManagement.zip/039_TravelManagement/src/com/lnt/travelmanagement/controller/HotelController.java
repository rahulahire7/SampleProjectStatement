package com.lnt.travelmanagement.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.exception.SpringException;
import com.lnt.travelmanagement.model.Hotel;
import com.lnt.travelmanagement.service.IHotelService;
import com.lnt.travelmanagement.validator.HotelValidator;

@Controller
public class HotelController {

	@Autowired
	HotelValidator validator;

	private IHotelService hotelService;

	@Autowired
	@Qualifier(value = "hotelService")
	public void setHotelService(IHotelService hotelService) {
		this.hotelService = hotelService;
	}

	@RequestMapping(value = "/showHotelLocationForm", method = RequestMethod.GET)
	public String showLocation(Model model) {

		model.addAttribute("hotels", new Hotel()); // model name

		return "ShowHotelLocationForm";// viewName
	}

	@RequestMapping(value = "/hotels", method = RequestMethod.POST)
	public String getHotelByLoc(@ModelAttribute("hotels") @Valid Hotel hotel, BindingResult result, Model model) {


			if (hotel.getLocation().equals("Mumbai") || hotel.getLocation().equals("Shimla")
					|| hotel.getLocation().equals("Nainital") || hotel.getLocation().equals("Kashmir")
					|| hotel.getLocation().equals("Kerela") || hotel.getLocation().equals("Rajasthan")
					|| hotel.getLocation().equals("Manali") || hotel.getLocation().equals("Goa")) {
				validator.validate(hotel, result);
				ArrayList<Hotel> hotelList = hotelService.getHotelByLoc(hotel.getLocation());

				if (result.hasErrors()) {
					return "locationForm";
				}
				model.addAttribute("hotelList", hotelList);

				return "showHotelList";// viewName
			}
			return "ShowHotelLocationForm";
		

	}
}
	
