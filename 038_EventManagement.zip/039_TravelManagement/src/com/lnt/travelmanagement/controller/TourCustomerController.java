package com.lnt.travelmanagement.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.travelmanagement.dao.TourCustomerDao;
import com.lnt.travelmanagement.model.TourCustomer;
import com.lnt.travelmanagement.service.ITourCustomerService;
import com.lnt.travelmanagement.service.ITravelService;

@Controller
public class TourCustomerController {
	private static final Logger logger = LoggerFactory.getLogger(TourCustomerDao.class);

	ITourCustomerService tourCustomerService;
	ITravelService travelService;

	@Autowired
	public void setHotelCustomerService(ITourCustomerService tourCustomerService) {
		this.tourCustomerService = tourCustomerService;
	}

	@RequestMapping(value = "/tourcustomers", method = RequestMethod.POST)
	public String listHotelCustomer(Model model) {
		model.addAttribute("tourCustomer", new TourCustomer());// model
		return "register";// view name
	}

	

	@RequestMapping(value = "/tourbooking/{tourId}/{costPerPerson}/{type}", method = RequestMethod.GET)
	public String showHotelCustomers(@PathVariable("tourId") Integer tourId,
			@PathVariable("costPerPerson") Double amount, @PathVariable("type") String type, Model model) {
		TourCustomer tourCustomer = new TourCustomer();
		model.addAttribute("tourId", tourId);
		model.addAttribute("totalamount", amount);
		model.addAttribute("tourCustomer", tourCustomer);
		logger.info(" Tour id : " + tourId);
		logger.info(" Booking amount : " + amount);
		if (type.equals("family") || type.equals("friends")) {
			return "registerCustomer";

		}
		return "registerCoupleCustomer";

	}

	@RequestMapping(value = "/customerBooking", method = RequestMethod.POST)
	public String addHotelCustomers(@ModelAttribute("tourCustomer") @Valid TourCustomer tourCustomer,
			BindingResult result, Model model) {
		logger.info(" from Customer Booking form: " + tourCustomer);
		logger.info("no of person: " + tourCustomer.getNoOfPerson());
		logger.info("amount: " + tourCustomer.getAmount());

		tourCustomerService.addTourCustomer(tourCustomer);
		logger.info("customer id: " + tourCustomer.getCustomerId());

		model.addAttribute("custId", tourCustomer.getCustomerId());

		if (tourCustomer.getNoOfPerson()!=2) {
			tourCustomerService.updateTotalAmount(tourCustomer.getCustomerId(), tourCustomer.getAmount(),
					tourCustomer.getNoOfPerson());
		}

		TourCustomer customer = tourCustomerService.getCustomerById(tourCustomer.getCustomerId());
		model.addAttribute("customerList", customer);
		logger.info("customer data : " + customer);
		return "bookingSuccessful";
	}

}
