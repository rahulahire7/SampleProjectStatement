/**
 * 
 */
package com.lnt.travelmanagement.controller;

import java.io.Serializable;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.exception.SpringException;
import com.lnt.travelmanagement.dao.EmployeeLoginDao;
import com.lnt.travelmanagement.model.Attendance;
import com.lnt.travelmanagement.model.Employees;
import com.lnt.travelmanagement.model.TourCustomer;
import com.lnt.travelmanagement.service.IEmployeeService;

@Controller
public class EmployeeController implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7293271362277354705L;

	private static final Logger logger = LoggerFactory.getLogger(EmployeeLoginDao.class);

	private IEmployeeService employeeService;
	private HttpSession session;

	@Autowired
	@Qualifier(value = "employeeService")
	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	// Show employee login form
	@RequestMapping(value = "/showEmployeeLoginForm", method = RequestMethod.GET)
	@ExceptionHandler({ SpringException.class })
	public String showEmployeeLogin(Model model, HttpServletRequest request) {
		session = request.getSession();

		if (session != null) {
			session.setMaxInactiveInterval(60 * 60);// 6 mins
			model.addAttribute("employees", new Employees()); // model name

			return "employeeLoginForm";// viewName
		} else {
			throw new SpringException("Session Already Terminated!!");
		}
	}

	// Validate employee
	@RequestMapping(value = "/validateEmp", method = RequestMethod.POST)
	public String submit(@ModelAttribute("employees") @Valid Employees employees, BindingResult result, Model model,
			HttpSession session, HttpServletRequest request, HttpServletResponse response) {

		if (!result.hasErrors()) {

			String userExists = employeeService.checkEmployeeLogin(employees.getEmpId(), employees.getEmpPassword());
			if (userExists != null) {
				model.addAttribute("empId", employees.getEmpId());
				model.addAttribute("empPassword", employees.getEmpPassword());
				logger.info("*****************************" + userExists + " in validate emp");

				if (userExists.equals("Manager")) {
					session = request.getSession(true);
					session.setAttribute("employees", employees);
					return "managerHome";
				}
				if (userExists.equals("Clerk")) {
					session = request.getSession(true);
					return "attendance";
				}

			}
		}
		return "employeeLoginForm";
	}

	@RequestMapping(value = "/update/{empId}", method = RequestMethod.POST)
	public String update(@PathVariable("empId") @Valid Integer empId, Model model) {

		model.addAttribute("empId", empId);
		int result = employeeService.updateAttendance(empId);

		if (result > 0) {
			return "success";
		}
		return "attendanceAlreadyDone";

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(HttpSession session) {
		Employees employees = (Employees) session.getAttribute("employees");
		employees = new Employees();
		logger.info("session invalidate ");
		session.invalidate();
		return "redirect:/showEmployeeLoginForm";
	}

	@RequestMapping(value = "/showAllEmployee", method = RequestMethod.GET)
	public String showAllEmployees(Model model) {
		ArrayList<Employees> employeelist = employeeService.listAllEmployee();

		// model.addAttribute("employees",Employees);
		model.addAttribute("employeeList", employeelist);

		return "showEmployeeList";
	}

	@RequestMapping(value = "/showAllCustomer", method = RequestMethod.GET)
	public String showAllCustomers(Model model) {
		ArrayList<TourCustomer> customerlist = employeeService.listAllCustomer();
		model.addAttribute("customerlist", customerlist);

		return "showCustomerList";
	}

	@RequestMapping(value = "/showAllAttendance", method = RequestMethod.GET)
	public String showAttendance(Model model) {
		ArrayList<Attendance> attendancelist = employeeService.listAllAttendance();
		model.addAttribute("attendancelist", attendancelist);

		return "showAllAttendance";
	}

}
