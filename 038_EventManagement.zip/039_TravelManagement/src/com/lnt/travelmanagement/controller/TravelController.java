
package com.lnt.travelmanagement.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.travelmanagement.model.Travel;
import com.lnt.travelmanagement.service.ITravelService;

@Controller
public class TravelController {

	private ITravelService travelService;

	@Autowired
	@Qualifier(value = "travelService")
	public void setTravelService(ITravelService travelService) {
		this.travelService = travelService;
	}

	@RequestMapping(value = "/")
	public String showHomePage(Model model) {

		model.addAttribute("tours", new Travel()); // model name

		return "index";// viewName
	}

	
	@RequestMapping(value = "/Location", method = RequestMethod.GET)
	public String showLocation(Model model) {

		model.addAttribute("tours", new Travel()); // model name

		return "LocationForm";// viewName
	}

	@RequestMapping(value = "/tour", method = RequestMethod.POST)
	public String searchByLocation(@ModelAttribute("tours") Travel travel, BindingResult Result, Model model) {

		if (travel.getToLocation() == null) {
			return "index";
		}
		if (travel.getToLocation().equals("Mumbai") || travel.getToLocation().equals("Shimla")
				|| travel.getToLocation().equals("Nainital") || travel.getToLocation().equals("Kashmir")
				|| travel.getToLocation().equals("Kerela") || travel.getToLocation().equals("Rajasthan") ||
				travel.getToLocation().equals("Manali") || travel.getToLocation().equals("Goa")) {
			ArrayList<Travel> travelList = travelService.searchByLocation(travel.getToLocation());
			model.addAttribute("tourlist", travelList);
			return "travelListForm";// viewName
		} 
		return "LocationForm";

	}

	@RequestMapping(value = "/blogs")
	public String blogs(Model model) {
		model.addAttribute("tours", new Travel());
		return "blogs";// viewName
	}

	
}
