package com.lnt.travelmanagement.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.travelmanagement.model.Employees;
import com.lnt.travelmanagement.service.IAttendanceService;

@Controller
public class ManagerController 
{
	
	private IAttendanceService attendanceService;

	/**
	 * @param attendanceService the attendanceService to set
	 */
	@Autowired
	@Qualifier(value="attendanceService")
	public void setAttendanceService(IAttendanceService attendanceService) {
		this.attendanceService = attendanceService;
	}
	
	@RequestMapping(value="/showAll", method=RequestMethod.GET)	
	public String showAllEmployees(Model model) {
			ArrayList<Employees> employeelist=attendanceService.listAllEmployee();
			model.addAttribute("employeeList", employeelist);
			
		return "showEmployeeList";
	}
	
}
