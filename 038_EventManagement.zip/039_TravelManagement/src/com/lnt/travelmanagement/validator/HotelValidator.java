package com.lnt.travelmanagement.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.lnt.travelmanagement.model.Hotel;

@Component
public class HotelValidator implements Validator {

	@Override
	public boolean supports(Class c) {
	
		return Hotel.class.isAssignableFrom(c);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "location","error.location", "please enter location ");

	}

}
