

create table hotels (
hotel_id  number primary key,
hotel_name varchar2(30),
hotel_location varchar2(30),
hotel_ratings varchar2(20),
hotel_contact_no number,
hotel_address Varchar2(80),
hotel_facility varchar2(80),
hotel_meals varchar2(30),
hotel_pickup varchar2(30),
hotel_drop varchar2(30)
);

create sequence HOTEL_SEQ
MINVALUE 1
  MAXVALUE 100
  START WITH 1
  INCREMENT BY 1;

  
select * from hotels;

insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Paradise', 'Mumbai', '3 Star',8957486215, 
'Palm Beach road, Vashi, Mumbai-400253',
'AC/NON AC,  swimming pool,gym ',
'breakfast,lunch ,dinner',
'CST','Santacruz'
);

insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Oberoi', 'Mumbai', '5 Star',8596252145, 
'Near Marine drive, Mumbai-400250',
'AC/NON AC,  swimming pool,gym ',
'breakfast,lunch ,dinner',
'Bandra','Santacruz'
);

insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel elite inn', 'Mumbai', '2 Star',8956486215, 
'Near Asian paints. turbhe, Mumbai-400226',
'AC/NON AC',
'breakfast,lunch ,dinner',
'Andheri','Worli'
);



insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Sun & Sand', 'Goa', '3 Star',8957486215, 
' Rua Miguel de Loyola Furtado, Margao, Goa 403601',
'AC/NON AC,  swimming pool, gym ',
'breakfast,lunch ,dinner',
'Colava','Patto'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Castle', 'Goa', '3 Star',8957486215, 
'SGO Complex,  Patto, Panaji, Goa 403001',
'AC/NON AC,  swimming pool,wi-fi ',
'breakfast,lunch ,dinner',
'Patto','Colava'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Fountain', 'Goa', '5 Star',8957486215, 
' Opposite Colva Football ground,Goa 403708',
'AC/NON AC,  swimming pool,gym, wi-fi',
'breakfast,lunch ,dinner',
'Margao','Patto'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel residency', 'Goa', '3 Star',8957486215, 
'  Near Vaddem Lake Opp. Radio Mundial, Vasco da Gama, Goa 403802',
'AC/NON AC,  swimming pool, wi-fi',
'breakfast,lunch ,dinner',
'Margao','Colava'
);





insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Center Point', 'Nainital', '5 Star',8957486215, 
' Tallital, Nainital, Uttarakhand 263002',
'AC/NON AC,  swimming pool,gym, wi-fi',
'breakfast,lunch ,dinner',
'Zoo Road','Mallital'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Rajwada', 'Nainital', '5 Star',8957486215, 
' Zoo Road, Nainital, Uttarakhand 263001',
'AC/NON AC,  swimming pool,gym, wi-fi',
'breakfast,lunch ,dinner',
'Mallital','Tallital'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Royal', 'Nainital', '5 Star',8957486215, 
' Ayarpatta Hill, Mallital, Nainital, Uttarakhand 263002',
'AC/NON AC,  swimming pool,gym, wi-fi',
'breakfast,lunch ,dinner',
'Tallital','Mallital'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Ashoka', 'Nainital', '5 Star',8596386215, 
'Mall Rd, Opposite Library, Mallital, Nainital, Uttarakhand 263002',
'AC/NON AC,  swimming pool,gym, wi-fi',
'breakfast,lunch ,dinner',
'Tallital','Zoo Road'
);





insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Radisson Blue', 'Shimla', '2 Star',8957486215, 
' Cart Rd, Shimla, Himachal Pradesh 171001',
'AC/NON AC, wi-fi',
'breakfast,lunch ,dinner',
'Kachi Ghati','Jakhoo'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Center Point', 'Shimla', '2 Star',8957486215, 
'Kachi Ghatti, Shimla, Himachal Pradesh 171005',
'AC/NON AC,  wi-fi',
'breakfast,lunch ,dinner',
'Jakhoo','Cart Rd'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Richards', 'Shimla', '3 Star',8957486215, 
' Near St. Bedes College, Shimla, Himachal Pradesh 171002',
'AC/NON AC, gym, wi-fi',
'breakfast,lunch ,dinner',
'Kachi Ghati','Jakhoo'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel TAJ', 'Shimla', '5 Star',8957486215, 
'Jakhoo Rd, Jakhoo, Shimla, Himachal Pradesh 171001',
'AC/NON AC, gym, wi-fi',
'breakfast,lunch ,dinner',
'St. Bedes College','Cart Rd'
);







insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Amrut', 'Rajasthan', '2 Star',8087586215, 
' Moti Doongari Road, Jaipur, Rajasthan 302004',
'AC/NON AC,  swimming pool, gym ',
'breakfast,lunch ,dinner',
'Fort Kotari Para','Gangapole'
);

insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Raj', 'Rajasthan', '2 Star',7757486215,
'On Fort Kotari Para, Jaisalmer, Rajasthan 345001',
'AC/NON AC,  swimming pool'
'breakfast,lunch ,dinner',
'Moti Doongari Road','Jorawar Singh Gate'
);




insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Bluemoon', 'Manali', '3 Star',7847486215,
'Hadimba Road, Manali, Himachal Pradesh 175131',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
'Zanskar','Nyak Tso'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Tuli', 'Manali', '3 Star',7847486215,
'Kanyal Rd, Simsa Village, Manali, Himachal Pradesh 175131',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
'Circuit House Road','Zanskar'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Tuli Imperial', 'Manali', '3 Star',7847486215,
'Circuit House Road, Manali, Himachal Pradesh 175131',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
'Zanskar','Nyak Tso'
);


insert into hotels values( HOTEL_SEQ.NEXTVAL, 
'Hotel Sunrise', 'Kashmir', '2 Star',7757486215,
' Kohna Khan, Dalgate, Srinagar, Jammu and Kashmir 190001',
'AC/NON AC,  swimming pool',
'breakfast,lunch ,dinner',
'Rainawari',' Pahalgam'
);
insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Seawood', 'Kashmir', '3 Star',7847486215,
'Jammu and Kashmir, Hazratbal Rd, Near JLNM Hospital, Rainawari, Srinagar, 190003',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
' Pahalgam','Dalgate');
insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Heaven', 'Kashmir', '2 Star',8697486215,
'Karapura, Rainawari, Srinagar, Jammu and Kashmir 190006',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
'Dalgate',' Pahalgam'
);



insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Antilla', 'Kerela', '3 Star',785236215,
'East Nada, Thrissur District, Guruvayur, Kerala 680101',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
' Warriam Lane','TB Rd');
insert into hotels values( HOTEL_SEQ.NEXTVAL,
'Hotel Le Meridian', 'Kerela', '5 Star',9456386215,
'Guruvayoor, Opposite Municipal Bus Stand, Thrissur, Kerala 680101',
'NON AC,gym,wi-fi ',
'breakfast,lunch ,dinner',
'Guruvayur','Thrissur');

