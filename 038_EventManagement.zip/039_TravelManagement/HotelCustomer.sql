create sequence CUST_SEQ
MINVALUE 1
  MAXVALUE 500
  START WITH 1
  INCREMENT BY 1;


create table hotel_customer(
cust_id NUMBER,
cust_name VARCHAR2(30),
cust_age NUMBER,
cust_email VARCHAR2(30),
cust_phone NUMBER,
total_person NUMBER
);


insert into hotel_customer values(
CUST_SEQ.nextval,'prachi',22,'prachi@g.com',895748693,3
);
