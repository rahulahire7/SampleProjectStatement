
create table attendance(
emp_id NUMBER,
present_days NUMBER,
emp_salary NUMBER,
month DATE,
total_salary NUMBER
)

drop table attendance;


insert into attendance values(1021,0,2500,to_char(sysdate,'DD/MON/YYYY'),0);
insert into attendance values(1022,0,2500,to_char(sysdate,'DD/MON/YYYY'),0);
insert into attendance values(1023,0,2500,to_char(sysdate,'DD/MON/YYYY'),0);