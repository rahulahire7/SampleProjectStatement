drop table Employee;
create table Employee(
emp_id NUMBER PRIMARY KEY,
emp_name VARCHAR2(30) NOT NULL,
password VARCHAR2(30),
emp_type VARCHAR2(30)
);
drop sequence EMP_SEQ;
create sequence EMP_SEQ
MINVALUE 1001
MAXVALUE 9999
  START WITH 1001
  INCREMENT BY 1;
  
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Anudeep', 'user1001','Non-Moving', 'Manager');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Megha', 'user1002','Non-Moving', 'Clerk');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Rama', 'user1003','Non-Moving', 'Clerk');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Prachi', 'user1004', 'Moving','Driver');
  INSERT INTO Employee values(EMP_SEQ.NEXTVAL, 'Sonali', 'user1005', 'Moving','Driver');

  select * from Employee;