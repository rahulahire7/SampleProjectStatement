create table tour_customer(
customer_id NUMBER PRIMARY KEY,
tour_id NUMBER REFERENCES Travel(tour_id),
customer_name Varchar2(30),
customer_email Varchar2(50),
phone_number NUMBER,
NO_OF_PERSON NUMBER,
amount NUMBER
);